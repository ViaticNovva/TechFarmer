@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run INSTALL-WINDOWS.cmd first. Vision and model steps are optional for reference matching.
  pause
  exit /b 1
)
echo TechFarmer - keep this PC and console running. Ctrl+C stops the bot.
echo Enter the token ONLY at the hidden local prompt, never in the HTML page, config or chat.
".venv\Scripts\python.exe" -m tech_farmer run
set "TF_EXIT=%ERRORLEVEL%"
echo Process stopped. After a restart, explicitly resume interrupted jobs with /farmer control.
echo If device policy blocks installation or running, stop and get approval; do not bypass it.
pause
exit /b %TF_EXIT%
