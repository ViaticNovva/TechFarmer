# Validation and release gates — TechFarmer 0.3.0

Canonical source: https://github.com/ViaticNovva/TechFarmer. This report distinguishes implementation, executed tests, injected fixtures and unverified deployment/recognition. No live app, bot connection, credentials, third-party artwork collection or remote Git push was performed while building the source.

## Recorded v0.3 candidate execution — 2026-10-25

The **one sequential full run** of `python -m unittest discover -s tests -v` ran **259 tests in 365.158 seconds**: 250 passed, 8 explicitly skipped, and **one updater crash test failed and also raised a teardown error**. Unittest reported `FAILED (failures=1, errors=1, skipped=8)`: both unsuccessful records belong to the same test, not two distinct failed tests. This was **not a green full suite**. The log is local/ignored `.runtime/v03-full-tests.log`.

The failing case was `test_real_process_crash_is_recovered_without_network_and_bot_cannot_start_mid_update`. Its child returned 1 rather than intentional crash exit 73, after the updater reported a failed update with previous source/manifest restored. The intended crash/recovery assertions therefore did not complete in this run. Cleanup separately raised `OSError: [Errno 5] Input/output error` while unlinking the fixture's staged `UPDATE-WINDOWS.cmd`. The workspace is FUSE; these observations do not prove a production overwrite bug, but they also do **not** verify this final full-run crash case. No production durability/hash/rollback checks were weakened and no repeated full run was used to hide the result.

The 8 skips were **five actual discord.py SDK tests**, **one actual tiny OWLv2 API test**, and **two real symlink/hardlink updater tests** because this filesystem cannot create those links. All other full-run cases—including actual SQLite migration/native files, backup-failure preservation, source-host approval, no-model collection, exact pixels, storage receipts/unknown outcomes and the other disk-backed updater cases—passed.

Separate, deliberately retained evidence:

- Core storage target: **9/9 passed** on real local files/SQLite before the final revocation regression was added.
- New workflow target: **12/12 passed in 21.307s**, before one additional backup-failure case (which passed in the full run).
- Earlier updater physical suite: **48 tests: 42 passed, 4 errors, 2 platform skips**. Errors included safe rollback/needs-attention outcomes and a child-process timeout; the existing FUSE failures remain part of the ledger, not converted into passes.
- A distinct three-case updater target passed **3/3 in 103.087s**: cancellation/rollback/retry, removed-source restoration, and actual `os._exit(73)` process-crash recovery. Only the test child timeout changed from 20 to 120 seconds for slow filesystem staging; exit/recovery/hash assertions were unchanged.
- Another three-case updater target passed **3/3 in 16.086s**: directory-entry syncing, explicit dependency-failure/source rollback with `.venv` preservation, and unsafe-journal refusal. These targeted successes do not erase the earlier/full-run failures or certify power-loss durability.
- **Final necessary changes after the full run:** optional dependency sync was corrected to inherit the operator's normal approved pip/index/proxy configuration, and storage consent can now be revoked after global rights consent is off. Their **three targeted real-file tests passed 3/3 in 11.389s**. Package execution was an injected sink, not a real pip/network install. The final source contains 260 tests; no second full run is claimed.

Setup JavaScript/launcher static checks and parsing every Python source passed. The authored pipeline demo and final source-integrity verification are separate from the above suites. No claimed test connects Discord, downloads artwork/model weights or executes a real package install.

Independent read-only review reproduced the stale source-approval, cross-issue pagination, empty-source updater and event-loop lock defects and verified their fixes. It separately exercised source/model geometry, owner/guild/no-fallback routes, SDK-free storage outcomes, consent-generation races and pip argument/environment handling under write/network-blocking audit hooks. Those memory-only reviews are **not independent on-disk rollback evidence**. Final release clearance requires the reviewer's before/after check of the exact frozen manifest. Native Windows, real SDK/TLS/source fetching, remote CI, pretrained inference and character accuracy remain unverified here.

## Environment and missing capabilities

Local Python **3.12.15**, Pillow **12.3.0**, BeautifulSoup **4.15.0** were available. `discord`, `aiohttp`, `torch`, `transformers`, `safetensors` and `httpx` were absent. Prior ordinary package installation had failed DNS; no alternate registry, proxy, DNS or credential workaround was attempted. Consequently, local SDK/pretrained execution is not claimed. Skips must remain visible.

The source targets Python 3.11/3.12. Windows `.cmd` files and setup JavaScript were examined/executed only as **static/DOM-simulation checks on Linux**, not a native Windows install/start. Nothing in this report proves OAuth authorization, a Discord server install, live private attachments, GPU performance, real website compatibility or comic-character accuracy.

## Reproduce offline tests

From the repository root, with lightweight image/parser dependencies available:

```sh
python -m unittest discover -s tests -v
node tests/test_setup.cjs
python tools/demo.py
python -m compileall -q tech_farmer tools tests
python tools/verify_manifest.py
```

Tests generate all HTML/image/cache fixtures procedurally under their own project-relative folders and clean them afterward. The demo retains its own ignored `.runtime/demo-.../` originals, SQLite state, crops and provenance for inspection; it creates no publishable image, archive or external-site copy. Never commit `.runtime/`, private data, exports, real configuration or cache files.

### What the executed fixture tests establish

- Native Pillow crop dimensions/pixels, aspect and asymmetric side controls, shape alpha masks, unchanged source/reference hashes, preserved originals and separate reframe edits.
- True reference flow into the matcher invocation: jobs freeze multiple identity references from a single profile; framing references are separate. Model tests use private injected processor/model primitives to check `query_images`, `query_pixel_values`, image-guided inference calls, post-processing, scale-back, tiled coordinates, NMS/reference aggregation, safe loads, cancellation and explicit detection budgets. **These doubles are not detection accuracy evidence.**
- Missing real model dependencies/cache fail closed, before page fetching, without fabricated matching or automatic download.
- Actual SQLite persistence: consent/owner scope, source-page dedupe, candidate state, pause/resume/restart, cancellation, partial failures, preserved completed pages, honest discovery incompleteness and quotas.
- Safety regressions: stable unsigned seed persistence, denied secret/credential queries, control transaction races, revocation/cancellation while slow readiness/image operations wait, source identity changes, and quota-limited reframing that preserves the candidate/original.
- Exact final PNG byte exports and batching/oversize policy. Public Discord provenance excludes source locations; local provenance retains only permitted unsigned routing identities. No per-export eight-crop total cap.
- Safe source transport with self-authored response streams, public-address pinning, redirect/origin/path constraints, no credentials/cookies/referrer/proxy forwarding, robots/access/challenge refusal, bounded readers and explicit partial discovery. Production connector construction is checked using a transport/SDK primitive double, not actual HTTP.
- Setup strict IDs, conservative OAuth scopes/permissions, no token fields/background network/browser storage, nonsecret JSON downloads, explicit source rights and Windows launcher static checks.

The end-to-end `tools/demo.py` uses the **actual SourceClient, Store, JobRunner and crop/export implementation**, synthetic reader pagination/HTML/images, and an obviously fixed-answer injected `FixtureMatcher` from `tests/helpers.py`. It tests the automatic URL-to-export workflow without a token or network. The fixed answer is never selectable from production configuration or commands.

## Actual SDK gate (required in lightweight CI)

```sh
python -m pip install -r requirements.txt
python -c "import discord, aiohttp; from tech_farmer.bot import FarmerClient, FarmerGroup; print(discord.__version__)"
TECH_FARMER_REQUIRE_SDK=1 python -m unittest discover -s tests -v
```

On PowerShell set `$env:TECH_FARMER_REQUIRE_SDK='1'` before running the test command; on Windows cmd use `set TECH_FARMER_REQUIRE_SDK=1`.

`tests/test_sdk.py` imports real discord.py, serializes the actual application command tree and button views, and constructs real `discord.File`/mention settings for mocked private response sinks. It does not log in. When SDK packages are absent locally, these five tests explicitly skip. They cover the real command tree (including optional attachment/profile options and the 25-command group bound), startup guild synchronization, bound approval buttons/owner checks, unchanged interaction-attachment validation, effective channel permissions from real SDK objects, and persistent sends with real `discord.File`/suppressed mentions. HTTP/response sinks are mocked; no login occurs. **Setting `TECH_FARMER_REQUIRE_SDK=1` makes absence a hard failure**, never a silently skipped CI success.

`.github/workflows/ci.yml` has read-only repository permissions, no supplied secrets and no credential persistence. Its Python 3.11/3.12 lightweight job installs only base requirements, verifies reviewed source hashes, requires SDK imports, runs tests/JS checks and the authored demo. A separate **read-only `windows-latest`/Python 3.12 job** runs only the offline updater fixture suite and setup/launcher static checks, without models, Discord login, real source requests, an interactive updater or secrets. It can supply native-Windows Python/filesystem evidence only after it actually runs; launcher static checks still do not prove a native manual install. Remote CI results must be checked after publication; this source report is not a claim any remote job has run or passed.

## Optional real OWLv2 checks — separate evidence levels

1. **Tiny random-weight API smoke:** with vision dependencies installed, `tests/test_vision_framing.py` builds a tiny actual OWLv2 configuration and tokenizer from self-authored files, invokes the actual processor/model/postprocessor, and checks shape/API compatibility. It does not download pretrained weights and is not recognition evidence. Without the optional dependencies this one test explicitly skips.
2. **Pretrained API execution:** explicit user-controlled commands below download the pinned safetensors model and run it locally against generated shapes. Successful execution still would not prove comic-character identity accuracy.
3. **Real recognition evaluation:** not performed. It needs user-permitted representative references/pages, manually labeled ground truth, false-positive/miss accounting, crop quality review, environment details and benchmark methodology. No accuracy percentage is invented.

```sh
python -m pip install -r requirements-vision.txt
python -m unittest discover -s tests -p test_vision_framing.py -v
python -m tech_farmer download-model --model-cache .cache/models --device cpu
python -m tech_farmer doctor --model-cache .cache/models --device cpu
python tools/model_smoke.py
```

The heavy CI job runs **only** on an explicit `workflow_dispatch` with `pretrained_smoke=true`. It is not triggered on every file commit/push/PR. Both download and inference may require several GB; no local pretrained execution is asserted here. Imports/doctor/load are local-only except the explicit `download-model` command.

## Review and browser-publication integrity

Independent review identified and drove fixes for credential-bearing seed persistence, safety-control lock availability, control race/cancellation resurrection, reframe/storage quotas, repeated-image occurrence loss, implicit page identity on reorder, IPv6 site-local address filtering and incremental bounded native-crop encoding before quota checks. Review is separate from recognition/deployment validation. Publish only after the parent/release owner accepts the final reviewed text manifest.

`SOURCE-MANIFEST.sha256` is the source publication list and byte-level integrity contract. `tools/verify_manifest.py` checks every publishable UTF-8/LF text file (excluding the manifest itself and runtime/private/Git data). CI rejects missing/extra/changed source. A reviewer may regenerate with `--write` **after** reviewing changes; CI never regenerates. The manifest is not a signature or guarantee of model accuracy/security beyond the reviewed bytes. Publish the CI workflow last during browser-based multi-file publication, to avoid useless partial-tree runs. A local staging hash is not a remote commit.
