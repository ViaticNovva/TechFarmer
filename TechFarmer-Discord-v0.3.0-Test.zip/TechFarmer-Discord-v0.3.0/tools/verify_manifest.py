"""Verify browser-published text against reviewed source; --write is for the reviewer only."""
from __future__ import annotations

import argparse
from hashlib import sha256
from pathlib import Path
import os
import sys

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = "SOURCE-MANIFEST.sha256"
RUNTIME_DIRS = {".git", ".venv", ".runtime", ".cache", "data", "exports", "__pycache__", ".pytest_cache", "node_modules"}
RUNTIME_FILES = {"tech-farmer-settings.json", "source-profiles.json", ".env"}


def inventory() -> dict[str, str]:
    result = {}
    for folder, directories, files in os.walk(ROOT, followlinks=False):
        directories[:] = sorted(name for name in directories if name not in RUNTIME_DIRS)
        for name in directories:
            if (Path(folder) / name).is_symlink():
                raise ValueError("Publishable source must not contain directory links.")
        for name in sorted(files):
            path = Path(folder) / name
            relative = path.relative_to(ROOT)
            if (name in RUNTIME_FILES or any(name.startswith(private + ".backup-") for private in ("tech-farmer-settings.json", "source-profiles.json"))
                    or name.startswith(".env.") or name.endswith((".pyc", ".pyo", ".log", ".part")) or relative.as_posix() == MANIFEST):
                continue
            if path.is_symlink():
                raise ValueError("Publishable source must not contain symbolic links: " + relative.as_posix())
            raw = path.read_bytes()
            raw.decode("utf-8")
            if not raw.strip() or b"\r" in raw or b"\0" in raw or not raw.endswith(b"\n"):
                raise ValueError("Source must be nonempty UTF-8 text with LF newlines and a final newline: " + relative.as_posix())
            result[relative.as_posix()] = sha256(raw).hexdigest()
    return dict(sorted(result.items()))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true", help="Regenerate only after review; CI never uses this")
    args = parser.parse_args(argv)
    try:
        actual = inventory()
        path = ROOT / MANIFEST
        if args.write:
            path.write_text("".join(f"{value}  {name}\n" for name, value in actual.items()), encoding="utf-8", newline="\n")
            print(f"Wrote {MANIFEST}: {len(actual)} text source files. This is not a remote commit.")
            return 0
        expected = {}
        for line in path.read_text(encoding="utf-8").splitlines():
            value, name = line.split("  ", 1)
            if name in expected or len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
                raise ValueError("Malformed or duplicate manifest entry.")
            expected[name] = value
        missing = sorted(set(expected) - set(actual))
        extra = sorted(set(actual) - set(expected))
        changed = sorted(name for name in set(actual) & set(expected) if actual[name] != expected[name])
        if missing or extra or changed:
            print("Source integrity FAILED. Missing:", missing, "Extra:", extra, "Changed:", changed)
            return 1
        print(f"Verified {len(actual)} text source files against {MANIFEST}.")
        return 0
    except (OSError, UnicodeError, ValueError) as exc:
        print("Source integrity FAILED:", str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
