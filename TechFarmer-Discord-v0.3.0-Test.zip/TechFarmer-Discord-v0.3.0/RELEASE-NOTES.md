# TechFarmer v0.3.0 release notes

Canonical repository only: https://github.com/ViaticNovva/TechFarmer. Native Python; no hosted app, account change, live Discord post, artwork/model download or separate output ZIP was made during this build.

## Link first, reference optional

- New `/farmer pull url:<link>` defaults to **collect-pages** with no identity claim and no model prerequisite. Explicit `collect-panels` uses a labeled white-gutter heuristic. Optional `reference:<upload>` or `profile:<name>` selects real local image-guided OWLv2 matching; invalid/missing matching inputs never silently become collection.
- Bounded source inspection handles supported direct still raster images and recognized static reader/chapter lists without manual selectors. It retains safe DNS/socket binding, robots, redirect/access controls and resource limits. External image hosts require per-job approval of the **displayed immutable proposal**. Changed hosts/scope invalidate prior confirmation; cross-chapter pagination cannot borrow another issue's pages.
- `/farmer harvest` stays available with detailed crop controls. Same-character multi-reference snapshots, raw model scores, native pixels, originals, separate edits and local provenance remain preserved. A framing image guides aspect only; anatomy/pose is not fabricated.

## Explicit persistent private-channel storage

- `/farmer storage channel:<private text channel> accept:true` persists the owner-selected same-guild destination and its separate consent. Fresh REST channel/role/member checks run before each batch and resumed save. Public, news, thread, DM, forum, foreign-guild, missing-access and missing View/Send/Attach cases fail closed. No channel creation, permission mutation or current-channel fallback.
- `/farmer save job:<id> mode:accepted` sends only accepted matches. `mode:collection` explicitly sends complete no-reference results, never references. Three bounded batches per request; sent/already stored/unknown/oversized/remaining counts and the exact continuation command are reported.
- Durable per-output receipts deduplicate confirmed sends across restart. Uncertain/failed/interrupted sends are **unknown, not blindly retried**. SDK rate limits are respected without inventing unsupported nonce enforcement. Oversized native PNGs remain local, unchanged; no public/external fallback.
- Commands/errors/previews stay ephemeral. Channel messages/files are persistent but visible to every authorized member/role/admin and subject to Discord retention/limits—not a permanent archive or owner-only privacy. Keep local originals/exports/receipts.

## Setup, migration and updates

Base install/start/status/page collection no longer requires a source profile, vision packages or model weights. The local setup page has no token input/network/background storage; the optional storage ID is a suggestion until bot-side consent/validation. Tokens remain hidden-console/process-environment only; privileged intents/Admin are not requested. Restart syncs updated guild slash commands.

`UPDATE-WINDOWS.cmd` and `tools/update.py` use only the fixed canonical repository, verify the complete nonempty source manifest, preserve private configuration/data/cache/backups, and journal source updates under ignored `.runtime/update/`. Bot/CLI/updater share a runtime lock; the first old-version upgrade also needs local stopped-process acknowledgment. Discord `/farmer version` and `/farmer update` show version/check information only, never run Python or update code. First-time full-source upgrade, future single updater and rollback limitations are in README.

Settings schemas 1/2 migrate with exact backups. Compatible v0.2 SQLite state receives a backup and additive columns; IDs, references and review state survive. An incompatible v0.1/prototype database remains unchanged with an explicit **NOT migrated** notice and a new database. `/settings` and `/reload` only change documented numeric limits, never owner/guild/application/token/device/paths.

## Evidence and honest limits

See `TESTING.md` for the final sequential run, targeted results, earlier FUSE filesystem failures, exact skips and independent review. Real image/parser/SQLite/native-file fixture tests are distinct from injected model/network sinks. Actual discord.py/aiohttp imports and command serialization are required in lightweight CI; unavailable local SDK/model dependencies are not claimed tested. Native Windows, live Discord/TLS, third-party sites, pretrained inference and character accuracy remain unverified.

Unknown, ambiguous, JavaScript-only, authentication/paywall/CAPTCHA/DRM/robots-blocked sources are unsupported; no access workaround or universal-site claim exists. No supplied comic example or commercial art was fetched. OWLv2 is not verified character re-identification; scores are not accuracy percentages. Only previews are resized.

`SOURCE-MANIFEST.sha256` is the exact reviewed publishable text list, not a publisher signature or remote commit. Independent frozen-byte review and complete canonical publication remain the release owner's responsibility. The previous delivered v0.2 output copy is unchanged.

