"""Nonsecret setup and owner/guild routing; no network or Discord SDK doubles."""
import asyncio
import json
from pathlib import Path
from types import SimpleNamespace
import unittest

from tech_farmer.config import load_settings, snowflake
from tech_farmer.engine import JobRunner, crop_spec
from tech_farmer.images import png
from tech_farmer.safety import UserError
from tech_farmer.service import FarmerService, attachment_limit
from tech_farmer.store import Store
from tests.helpers import FixtureMatcher, FixtureSource, drawing, workspace


class ConfigTests(unittest.TestCase):
    def test_nonsecret_settings_round_trip_and_unknown_secret_refused(self):
        with workspace() as root:
            path = root / "settings.json"
            data = {"schema_version": 2, "owner_id": "123456789012345678", "guild_id": "234567890123456789", "application_id": "345678901234567890", "device": "cpu", "model_cache": ".cache/models", "pages_per_run": 3}
            path.write_text(json.dumps(data))
            settings = load_settings(path, environ={})
            self.assertEqual(settings.pages_per_run, 3)
            self.assertEqual(settings.device, "cpu")
            data["token"] = "not-a-real-token"
            path.write_text(json.dumps(data))
            with self.assertRaises(UserError):
                load_settings(path, environ={})

    def test_ids_paths_and_ranges(self):
        for value in ("", "01", "123456789012345678 ", "18446744073709551616", "secret.value"):
            with self.assertRaises(UserError):
                snowflake(value, "id")
        with workspace() as root:
            path = root / "settings.json"
            data = {"schema_version": 2, "owner_id": "123456789012345678", "guild_id": "234567890123456789", "application_id": "345678901234567890"}
            for key, bad in (("model_cache", "../escape"), ("device", "cloud"), ("pages_per_run", True), ("max_tiles", 33), ("detections_per_page", 1001)):
                path.write_text(json.dumps({**data, key: bad}))
                with self.assertRaises(UserError, msg=key):
                    load_settings(path, environ={})

    def test_crop_settings_reject_bad_values_and_no_anatomical_guess(self):
        for kwargs in ({"padding": "1,2,3"}, {"trim": "-1,0,0,0"}, {"aspect": "nan"}, {"shape": "circle", "aspect": "4:5"}):
            with self.assertRaises(UserError):
                crop_spec(**kwargs)
        self.assertEqual(crop_spec("face")["kind"], "face")


class Response:
    def __init__(self):
        self.defers = []

    async def defer(self, **kwargs):
        self.defers.append(kwargs)


def interaction(owner=101, guild=202, dm=False):
    return SimpleNamespace(user=SimpleNamespace(id=owner), guild_id=None if dm else guild,
                           guild=None if dm else SimpleNamespace(filesize_limit=8 * 1024 * 1024),
                           response=Response())


class CapturingService(FarmerService):
    """Captures only router output; actual discord.File/serialization are in test_sdk."""
    def __init__(self, *args):
        super().__init__(*args)
        self.messages = []

    async def reply(self, interaction, content, attachments=None, view=None):
        self.messages.append(content)


class ServiceTests(unittest.IsolatedAsyncioTestCase):
    async def test_every_action_checks_owner_and_guild_before_work(self):
        with workspace() as root:
            store = Store(101, 202, root / "data", root / "exports")
            runner = JobRunner(store, FixtureMatcher(), lambda: FixtureSource())
            service = CapturingService(store, runner, SimpleNamespace(storage_mib=2048))
            actions = ("help", "consent", "status", "doctor", "profiles", "reference", "harvest", "control", "review", "decide", "reframe", "export")
            for outsider in (interaction(owner=999), interaction(guild=999), interaction(dm=True)):
                for action in actions:
                    await service.run(outsider, action)
                    self.assertIn("Restricted", service.messages[-1])
                self.assertEqual(outsider.response.defers, [])
            self.assertFalse(store.has_consent())
            self.assertEqual(store.jobs(), [])

    async def test_authorized_defer_is_ephemeral_and_consent_gates_work(self):
        with workspace() as root:
            store = Store(101, 202, root / "data", root / "exports")
            runner = JobRunner(store, FixtureMatcher(), lambda: FixtureSource())
            service = CapturingService(store, runner, SimpleNamespace(storage_mib=2048))
            item = interaction()
            await service.run(item, "harvest")
            self.assertEqual(item.response.defers, [{"ephemeral": True, "thinking": True}])
            self.assertIn("consent", service.messages[-1])
            self.assertEqual(store.jobs(), [])
            await service.run(interaction(), "consent", accept=True)
            self.assertTrue(store.has_consent())
            await service.run(interaction(), "consent", accept=False)
            self.assertFalse(store.has_consent())

    async def test_missing_model_never_queues_substitute(self):
        with workspace() as root:
            store = Store(101, 202, root / "data", root / "exports")
            store.consent(True)
            matcher = FixtureMatcher()
            matcher.readiness = lambda: {"ready": False}
            runner = JobRunner(store, matcher, lambda: FixtureSource())
            service = CapturingService(store, runner, SimpleNamespace(storage_mib=2048))
            await service.run(interaction(), "harvest", url="https://fixture.invalid/chapter", profile="Hero")
            self.assertEqual(store.jobs(), [])
            self.assertIn("No dummy detector", service.messages[-1])

    async def test_safety_controls_bypass_slow_doctor_and_image_lock(self):
        import threading
        with workspace() as root:
            store = Store(101, 202, root / "data", root / "exports")
            store.consent(True)
            store.add_reference("Hero", png(drawing()))
            matcher = FixtureMatcher()
            runner = JobRunner(store, matcher, lambda: FixtureSource())
            job = store.create_job("https://fixture.invalid/series", "series", "Hero", crop_spec(), matcher.readiness())
            service = CapturingService(store, runner, SimpleNamespace(storage_mib=2048))
            entered, release = threading.Event(), threading.Event()
            def slow_readiness():
                entered.set()
                release.wait(10)
                return {"ready": True}
            matcher.readiness = slow_readiness
            doctor = asyncio.create_task(service.run(interaction(), "doctor"))
            try:
                self.assertTrue(await asyncio.to_thread(entered.wait, 3))
                async with service.owner_lock:
                    await asyncio.wait_for(service.run(interaction(), "control", job_id=job["id"], operation="cancel"), 3)
                    await asyncio.wait_for(service.run(interaction(), "consent", accept=False), 3)
                self.assertFalse(store.has_consent())
                self.assertEqual(store.job(job["id"])["control"], "cancel")
            finally:
                release.set()
                await doctor

    def test_conservative_runtime_attachment_limit(self):
        self.assertEqual(attachment_limit(SimpleNamespace(filesize_limit=100, guild=None)), 100)
        self.assertEqual(attachment_limit(SimpleNamespace(filesize_limit=200, guild=SimpleNamespace(filesize_limit=80))), 80)
        self.assertEqual(attachment_limit(SimpleNamespace(filesize_limit=None, guild=None)), 8 * 1024 * 1024)
